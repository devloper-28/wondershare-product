import React from "react";

const Header = () => (
  <header
    style={{ textAlign: "center", padding: "1rem", background: "#f8f8f8" }}
  >
    <h1>Welcome to Filmora Crack Product Site</h1>
  </header>
);

export default Header;
